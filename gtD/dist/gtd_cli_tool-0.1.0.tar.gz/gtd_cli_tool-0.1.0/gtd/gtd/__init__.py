"""
Get The Download (GTD) - A YouTube video downloader CLI tool.
"""

from .gtd import app, download

__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT" 